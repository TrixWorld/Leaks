﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace LoqiSploit1
{
    public partial class loqi : Form
    {
        ExploitAPI api = new ExploitAPI();
        public loqi()
        {
            InitializeComponent();
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            string text = fastColoredTextBox1.Text;
            api.SendLuaScript(text);
        }

        private void flatButton3_Click(object sender, EventArgs e)
        {
            api.LaunchExploit();
            string xtr = "loqi X injected";
            api.ConsoleWarn(xtr);

            string t1 = "Loqi X Loaded!";
            string t2 = "me";
            api.ForceBubbleChat(t2, t1);
        }

        private void flatButton2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "";
        }

        private void flatButton4_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) => fastColoredTextBox1.Text = System.IO.File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");

        private void flatCheckBox1_CheckedChanged(object sender)
        {
            api.DoBTools();
        }

        private void flatCheckBox2_CheckedChanged(object sender)
        {
            api.SetWalkSpeed();
        }

        private void flatCheckBox3_CheckedChanged(object sender)
        {
            api.ToggleClickTeleport();
        }

        private void flatButton7_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void FlatButton4_Click_1(object sender, EventArgs e)
        {
            string username = fastColoredTextBox2.Text;
            api.DoKill(username);
        }

        private void flatButton5_Click_1(object sender, EventArgs e)
        {
            string user = fastColoredTextBox3.Text;
            api.AddFire(user);
        }
        private void flatButton5_Click(object sender, EventArgs e)
        {

        }

    }
}
